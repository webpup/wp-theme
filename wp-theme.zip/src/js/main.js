import "../css/main.css";
console.log("Vite + WordPress HMR working 1123-301!");
