# WP-Theme

#### Wordpress starter theme with FSE, Block themes and TailwindCSS

### Installation

```bash
git clone https://github.com/webpup/wp-theme.git
```

## Docs

[webpup.github.io/wp-theme](https://webpup.github.io/wp-theme)
