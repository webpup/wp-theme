<?php
// Load Filters
require_once 'svg-filter.php';
require_once 'hide-admin-bar.php';
