<?php
/**
 * Plugin Name: Press Post Plugin
 * Description: A plugin to manage press releases.
 * Version: 1.0
 **/


//CPTs
require_once 'press-cpt.php';

//Rewrite Rules
require_once 'press-rewrite-rule.php';

