<?php
/**
 * Plugin Name: Blog Post Plugin
 * Description: A plugin to manage blog posts.
 * Version: 1.0
 **/


//Pim Enqueue Scripts
// require_once 'pim-enqueue-scripts.php';

//Pim CPT
require_once 'blog-cpt.php';

//Pim Rewrite Rule
require_once 'blog-rewrite-rule.php';

