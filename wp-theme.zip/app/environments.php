<?php
// Load the WordPress environment
define('IMAGE_URL', get_template_directory_uri() . '/assets/images');
define('CSS_URL', get_template_directory_uri() . '/assets/css');
define('JS_URL', get_template_directory_uri() . '/assets/js');
define('FONT_URL', get_template_directory_uri() . '/assets/fonts');
define('THEME_URL', get_template_directory_uri());
