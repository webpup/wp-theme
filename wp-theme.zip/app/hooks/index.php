<?php


// Load hooks
require_once 'custom-profile-image.php';