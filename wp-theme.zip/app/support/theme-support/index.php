<?php
// Load Custom Theme Support
require_once 'theme-support.php';
