<?php
// Load Customizer
// require_once 'customizer-controls.php';
// require_once 'customizer-sections.php';
// require_once 'customizer-panels.php';
// require_once 'customizer-settings.php';
// require_once 'customizer-sanitization.php';
// require_once 'customizer-preview.php';
// require_once 'customizer-publish.php';
// require_once 'customizer-helpers.php';
// require_once 'customizer-extensions.php';
