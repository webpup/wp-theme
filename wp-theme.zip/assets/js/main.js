console.log("Vite + WordPress HMR working 1123-30!");
